#!/bin/bash
cd "$(dirname "$0")"
echo "============================================"
echo "  간단공사내역서 - 내 컴퓨터에서 실행하기"
echo "============================================"

if [ ! -d "node_modules" ]; then
  echo "[1/3] 처음 실행 준비 중입니다. 잠시만 기다려주세요..."
  npm install
fi

if [ ! -d "dist" ]; then
  echo "[2/3] 앱을 빌드하고 있습니다..."
  npm run build
fi

echo "[3/3] 앱을 실행합니다. 잠시 후 브라우저가 자동으로 열립니다..."
(npm run preview -- --port 4173 &)
sleep 4
open http://localhost:4173
